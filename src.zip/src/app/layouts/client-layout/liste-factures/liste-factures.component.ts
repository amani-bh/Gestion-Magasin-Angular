import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-liste-factures',
  templateUrl: './liste-factures.component.html',
  styleUrls: ['./liste-factures.component.css']
})
export class ListeFacturesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

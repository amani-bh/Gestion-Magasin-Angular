export class fournisseur {
    idFournisseur!:number;
    code!:string;
    libelle!:string;
}